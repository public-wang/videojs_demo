
/*!VIPABC | Author by Mike Li*/
/*!v1.0 | 2015-9-22*/
/*!License: vipabc.com*/

var whichForm = 0;  // form serial
//var linkagePageForm = new Array();

var $linkagePageForm = $("form.linkagePage-form");  // find the form
var _length = $linkagePageForm.length; // the number of form

function getQueryString(name) {
    var reg = new RegExp("(^|&)" + name + "=([^&]*)(&|$)", "i");
    var r = window.location.search.substr(1).match(reg);
    //alert(r);
    if (r != null) {
        return unescape(r[2]);
    }
    return null;
}

var linkagePage_submit = function (object) {

    if (!validateForm(object)) {
        return false;
    }

    //Loading Animate
    loadingDiv(object);

    //get name
    var str_name = $.trim(object.find("input[data-type=name]").val());

    //get telephone
    var str_cphone = $.trim(object.find("input[data-type=tel]").val());

    //get email
    var str_mail = $.trim(object.find("input[data-type=email]").val()).toLowerCase();

    //get age
    var str_age_area = object.find("select").val();

    //get sex
    var str_sex = "";
    object.find("input[type=radio]").each(function (index, item) {

        if (item.checked) {

            str_sex = item.value;
        }
    });


    //VIPABC Adult User
    var str_jr = "0";

    //Distinguish VJR with VIPABC for CTI Call Center
    if (str_age_area == 8 || (str_age_area >= 20 && str_age_area <= 31 && str_age_area != 24)) {

        str_jr = "1";
        //VJR User

    }

    //get brand
    var str_brand = "";
    var $Brand = $("#forceAgeBranding");
    if ($Brand != "undefined") {
        //str_brand = $Brand.val();
    }

    var str_imgfilepath = $("#imgfilepath" + _reservedCourseId).val(); //发送邮件模板的北京图片名称
    var str_date = $("#sdate" + _reservedCourseId).val(); //获取本次大会堂的上课日期
    var str_isroster = $("#isroster" + _reservedCourseId).val(); //是否进派发流程 1为是，0为否

    var str_where = getQueryString("fromwhere"); //媒体来源

    if (str_where == null) {
        //get formwhere
        str_where = $("#fromwhere" + _reservedCourseId).val();
    }
    if (str_isroster == null) {
        str_isroster = "1";
    }

    var $str_enrollCount = $("#enrollCount" + _reservedCourseId); //获取报名人数的span
    //ajax submit data
    $.ajax({
        type: "POST",
        cache: false,
        url: "/Course/RegistLobby",
        dataType: "json",
        data: { "name": str_name, "cphone": str_cphone, "mail": str_mail, "age_area": str_age_area, "Gender": str_sex, "SessionDate": str_date, "fromwhere": str_where, "imgfilepath": str_imgfilepath, "isroster": str_isroster },
        success: function (data) {

            if (typeof window._gsTracker != 'undefined') {
                //--国双公共监测代码  start--
                if (window._gsTracker) {
                    _gsTracker.setCustomProperty('1', 'formSubmitted')
                    _gsTracker.track('/targetpage/submitOk/user/' + location.pathname)

                }
                //--国双公共监测代码  end--

                //--国双LiuYiRan监测代码 start--

                if (/landingpage\/LiuYiRan/.test(location.href)) {
                    if (window._gsTracker) {
                        var JSID = data.JSUUID;
                        _gsTracker.setCustomProperty('1', 'formSubmitted')
                        _gsTracker.track('/targetpage/submitOk/user/' + JSID + location.pathname)
                        _gsTracker.addOrder("JSID", 1);
                        _gsTracker.addProduct("JSID ", "submitOk", "submitOk", 1, 1, location.pathname);
                        _gsTracker.trackECom();
                    }
                }
//                //--国双LiuYiRan监测代码 end--
               // -- Sociomantic 监测代码 start--

                if(typeof sociomantic != "undefined"){
                        var randomTransactionId=function () {
                               var length = 6;
                               var chars = '0123456789abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ';
                               var timestamp = new Date().valueOf();
                               var result = '';
                               for (var i = length; i > 0; --i) result += chars[Math.round(Math.random() * (chars.length - 1))];
                               return result + timestamp;
                           }
                           sociomantic.sonar.adv['vipabc-cn'].clear();

                           window.sonar_lead = {
                               transaction: randomTransactionId() // 预约编号，如无任何编号可使用 randomTransactionId() 产生随机编号
                           };

                           sociomantic.sonar.adv['vipabc-cn'].track();
                // -- Sociomantic 监测代码 end--
                    }
               
            }

            // -- Sociomantic 监测代码 start--
            if (typeof sociomantic != "undefined") {

                // 如转换使用异步请求 AJAX，请将以下JS部署至填表送出成功后的事件里
                var randomTransactionId = function() {
                    var length = 6;
                    var chars = '0123456789abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ';
                    var timestamp = new Date().valueOf();
                    var result = '';
                    for (var i = length; i > 0; --i) result += chars[Math.round(Math.random() * (chars.length - 1))];
                    return result + timestamp;
                };

                sociomantic.sonar.adv['vipabc-cn'].clear();

                window.sonar_lead = {
                    transaction: randomTransactionId() // 预约编号，如无任何编号可使用 randomTransactionId() 产生随机编号
                };

                sociomantic.sonar.adv['vipabc-cn'].track();
            }
            // -- Sociomantic 监测代码 end--
            // Clear error message
            clearErrorMessage(object);
            // 改变按钮状态
            $(".waite").remove();

            object.find(".form-submit").val("立即报名");
            // $(".lightBox-bg").fadeOut(100);
            $(".lightBox-all, .lightBox-content").fadeOut(100);
            if (data.Status == "OK") {
                if (data.PlainResult == "registerdberror ") {
                    SimplePop.alert("网络繁忙，请您稍后重试");
                } else if (data.PlainResult == "registerhasregist") {
                    //SimplePop.alert("用户已注册");
                    msgBox.show(emailSignIn, str_mail);
                } else if (data.PlainResult == "registernovalid") {
                    //SimplePop.alert("用户未激活");
                    msgBox.show(emailActive,str_mail);

                } else if (data.PlainResult == "reservationfail") {
                    SimplePop.alert("网络繁忙，请您稍后重试");
                } else if (data.PlainResult == "otherbrand") {
                    SimplePop.alert("请使用正确的账号报名！");
                } else if (data.PlainResult == "over800") {
                    SimplePop.alert("非常抱歉，该课程预定人数已满，如有疑问，欢迎来电：4006-30-30-30");
                } else if (data.PlainResult == "hasreserved") {
                    SimplePop.alert("你已经报名过当前课程！");
                } else if (data.PlainResult == "noclient") {
                    SimplePop.alert("请使用正确的账号报名！");
                } else if (data.PlainResult == "timeout") {
                    SimplePop.alert("此课程时间已过！");
                } else if (data.PlainResult == "success") {
                    //SimplePop.alert("报名成功，报名信息已经发送到您的邮箱！如有疑问，欢迎来电：4006-30-30-30");
                    if(msgBoxNoRemind == null || msgBoxNoRemind !== "1" ){
                        msgBox.show(enterNewSuccess, str_mail);
                    }
                    // 改变按钮状态

                    $(obj).removeClass("open-signUp").addClass("btn-gray").text("已报名").removeAttr("onclick");
                    // window.location.reload();
                } else {
                    SimplePop.alert(data.PlainResult);
                }
            }
            else {
                SimplePop.alert("网络繁忙，请您稍后重试");
            }
                               
        },
        error: function (e) {
            SimplePop.alert("亲！服务器出错了哦，重新试一下吧！");
            clearErrorMessage(object);
            // 改变按钮状态
            $(".waite").remove();
        }
    });


    return false;

} 


function MyCourseAttendClass(index,obj,type) {

    _reservedCourseId = index;
    var str_imgfilepath = $("#imgfilepath" + _reservedCourseId).val(); //发送邮件模板的北京图片名称
    var str_date = $("#sdate" + _reservedCourseId).val(); //获取本次大会堂的上课日期
    var str_isroster = $("#isroster" + _reservedCourseId).val(); //是否进派发流程 1为是，0为否

    var str_where = getQueryString("fromwhere"); //媒体来源

    if (str_where == null || str_where == "") {
        //get formwhere
        str_where = $("#fromwhere" + _reservedCourseId).val();
    }
    if (str_isroster == null) {
        str_isroster = "1";
    }

    loadingDiv2(obj);



    //ajax submit data
    $.ajax({
        type: "POST",
        cache: false,
        url: "/Course/ReservationLobby",
        data: { "SessionDate": str_date, "fromwhere": str_where, "imgfilepath": str_imgfilepath, "isroster": str_isroster },
        dataType: "json",
        success: function (data) {
            // 改变按钮状态
            $(".waite").remove();

            if (data.Status == "OK") {
                if (data.PlainResult == "registerdberror") {
                    SimplePop.alert("网络繁忙，请您稍后重试");
                } else if (data.PlainResult == "registerhasregist") {
                    //SimplePop.alert("用户已注册");
                    msgBox.show(emailSignIn);
                } else if (data.PlainResult == "registernovalid") {
                    msgBox.show(emailActive, str_mail);
                    //SimplePop.alert("用户未激活");
                } else if (data.PlainResult == "reservationfail") {
                    SimplePop.alert("网络繁忙，请您稍后重试");
                } else if (data.PlainResult == "otherbrand") {
                    SimplePop.alert("请使用正确的账号报名！");
                } else if (data.PlainResult == "over800") {
                    SimplePop.alert("非常抱歉，该课程预定人数已满，如有疑问，欢迎来电：4006-30-30-30");
                } else if (data.PlainResult == "hasreserved") {
                    SimplePop.alert("你已经报名过当前课程！");
                } else if (data.PlainResult == "noclient") {
                    SimplePop.alert("请使用正确的账号报名！");
                } else if (data.PlainResult == "timeout") {
                    SimplePop.alert("此课程时间已过！");
                } else if (data.PlainResult == "success") {
                    //SimplePop.alert("报名成功，报名信息已经发送到您的邮箱！如有疑问，欢迎来电：4006-30-30-30");
                    // 首页和我的课程不同弹框
                     if (type == 'free') {
                        if(msgBoxNoRemind == null || msgBoxNoRemind !== "1" ){
                            msgBox.show(enterSuccess);
                        }
                    }else{
                        if(msgBoxNoRemind == null || msgBoxNoRemind !== "1" ){
                            msgBox.show(enterSuccess_Course);
                        }
                    }
                    $(obj).removeClass("open-signUp").addClass("btn-gray").text("已报名").removeAttr("onclick");
                    if (type != 'free') {
                        window.location.reload();
                    }
                } else {
                    SimplePop.alert(data.PlainResult);
                }
            }
            else {
                SimplePop.alert("网络繁忙，请您稍后重试");
            }

        },
        error: function (e) {
            SimplePop.alert("亲！服务器出错了哦，重新试一下吧！");
            clearErrorMessage(object);
            // 改变按钮状态
            $(".waite").remove();
        }
    });


    return false;
}




//Form submit button click event
$linkagePageForm.each(function (index, element) {

	var $this = $(this);

	$linkagePageForm.eq(index).attr("data-form", index);
	
	//Sign In submit
	
	$this.find(".form-submit").click(function (e) {

		linkagePage_submit($this);

	});


});


//make sure which form you have focused
$linkagePageForm.find("input").focus(function (index) {

	whichForm = $(this).closest("form").attr("data-form");
	//console.log(whichForm);
		
});



//keyword Enter submit
$(document).keydown(function (e) {

	if (e.keyCode == 13) {

		linkagePage_submit($linkagePageForm.eq(whichForm));

	}

});



