/*!VIPABC | Author by Mike Li*/
/*!v2.0 | 2015-11-3*/
/*!License: vipabc.com*/
var _reservedCourseId = 0;



/*
*  open Modal Wrap lightBox animate
*  Parameter: object  
*/
function openModalWrap(object) {

    if (object.is(":visible") == true) {
        return false;
    }
    var _top1 = 15;
    var _top2 = 25;

    if (vipabcUI.system.isPhone) {
        _top1 = 0;
        _top2 = 7;
    }

    object.animate({
        top: _top1 + '%',
        opacity: 0
    }, 0, function () {
        $(this).show();
    }).animate({
        top: _top2 + '%',
        opacity: 1
    }, 600);

}
/*
*  OpenSign as opening a sign warp
*  Parameter: index  
*/
function openSign(index) {

    $(".lightBox-bg").show();
    openModalWrap($(".openSession-sign-wrap"));
    _reservedCourseId = index;
    $(".openSession-sign-title ul li").eq(1).addClass("active").siblings().removeClass("active");
    $(".openSession-sign-content .item-centent").eq(1).addClass("active").siblings().removeClass("active");

    var StatPart = $("#StatPart" + _reservedCourseId).val();
    var fromwhere = $("#fromwhere" + _reservedCourseId).val();
    dataStatic(fromwhere, StatPart);



}


$(document).ready(function (e) {
    //close Modal Wrap lightBox
    $(".lightBox-close").click(function () {
        if ($("span.meg-error")) {

            clearErrorMessage($("form"));

        }
        $(".lightBox-bg").fadeOut(100);
        $(".lightBox-all, .lightBox-content").fadeOut(100);
    });



    //Mobile navigation follow the srcoll event
    if (vipabcUI.system.isPhone) {

        $(window).on("scroll", function () {

            var winTop2 = $(window).scrollTop();
            var $fixed2 = $(".mobile-nav");

            if (winTop2 > 400) {
                $fixed2.slideDown();
            } else {
                $fixed2.slideUp();
            }

        });

    }


    /*----------------- Limit the number of course description ----------------*/

    // maxLen = 125  the limited length of your  article
    $(".word-limited").each(function (index, element) {

        var txtStr = $(this).text();
        var maxLen = 60;

        if (txtStr.length > maxLen)

            $(this).text(txtStr.substring(0, maxLen) + " ...");

        else
            $(this).text(txtStr);

    });




});