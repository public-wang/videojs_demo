/*!
 * @author harrytang@vipabc.com
 * @date 16/11/20.
 */
+ function($, window, undefined) {

    $(function() {
        var englishBottomBanner = $(".js-english-bottom-banner");
        if ($.fn.slick && !!englishBottomBanner.length) {
            englishBottomBanner.slick({
                slidesToShow: 3,
                slidesToScroll: 1,
                autoplay: false,
                autoplaySpeed: 2000,
                prevArrow: "<div class='_icon-left'><i class='fa fa-angle-left'></i></div>",
                nextArrow: "<div class='_icon-right'><i class='fa fa-angle-right'></i></div>",
                arrows: true,
                dots: false,
                infinite: true,
                speed: 500,
                fade: false,
                cssEase: 'linear',
                responsive: [
                  {
                    breakpoint: 790,
                    settings: {
                      arrows: false,
                      centerMode: true,
                     //  centerPadding: '40px',
                      slidesToShow: 3,
                      dots: true,
                    }
                  },
                 {
                   breakpoint: 550,
                   settings: {
                     arrows: false,
                     centerMode: true,
                    //  centerPadding: '40px',
                     slidesToShow: 1,
                     dots: true,
                   }
                 }
               ]
            });
        }

    });

}(jQuery, window, undefined);
