/*!VIPABC | Author by Mike Li*/
/*!v2.0 | 2016-7-6*/
/*!License: vipabc.com*/

$(document).ready(function() {
    // Login
    /*---------- PC/平板 弹出层   登录/注册 -------------*/
    // if (!navigator.userAgent.match(/mobile/i)) {

    var wrap = new loginWrap($(".float-lay-bg, .login-register-wrap"));
    loginWrap.onDisplaying = function () {
        $(".online-service").stop(true, true);
        $(".online-service").hide();

    };

    wrap.onDismissing = function () {

    };



    var login = new loginPad(wrap);

});


var Is_show = false; //global variable

$(document).ready(function() {

  function nav_fixed() {

    var $offset = $(".header-fixed").offset();
    var $follow = $(".header");
    var $header_btn = $("#header-btn");
    var _top = 0;
    var winTop = $(window).scrollTop();
    if (winTop > $offset.top) {
      if (Is_show === false) {
        $follow.css({
          "position": "fixed",
          "_position": "absolute",
          "top": _top,
          "left": $offset.left,
          "box-shadow": "rgba(0, 0, 0, 0.4) 0px 1px 3px",
          "z-index": "4000"
        });

        $header_btn.fadeIn();
        Is_show = true;
      } else {
        $follow.css({"top": _top});
      }

      //$follow.addClass("form-wrap-active");

    } else {
      $follow.removeAttr("style");

      if ($header_btn.is(":visible")) {
        $header_btn.hide();
      }

      Is_show = false;
    }

  };

  //PC
  if (!navigator.userAgent.match(/mobile/i)) {
    $(window).on("scroll", function() {
      nav_fixed();
    });
    nav_fixed(); //Init

  }

  $(".knowmore").click(function(e) {

		// if($(".bg_lay")){
		// 	$(".bg_lay").remove();
		// }
		$(this).parent(".item-col").css("height", "auto");
		$(this).parent(".item-col").find(".roll").css("display", "block");
		$(this).css("display","none");

		return false;

	});

	$(".roll").click(function(e) {

		// if($(".bg_lay")){
		// 	$(".bg_lay").remove();
		// }
		$(this).parent(".item-col").css("height", "200px");
		$(this).parent(".item-col").find(".knowmore").css("display", "block");
		$(this).css("display","none");

		return false;

	});

	$.vForm.validate = function (rules) {
		var passport = true;

		for (var key in rules) {
			var isExist = !!this.find("[name='" + key + "']").length,
				validateTarget = this.find("[name='" + key + "']"),
				radio = isExist && $.nodeName(validateTarget[0], "INPUT") && validateTarget[0].type == "radio",
				checkbox = isExist && $.nodeName(validateTarget[0], "INPUT") && validateTarget[0].type == "checkbox",
				normalInput = isExist && $.nodeName(validateTarget[0], "INPUT") && !radio && !checkbox;

			normalInput && validateTarget.trigger("blur");
			if (isExist && $.nodeName(validateTarget[0], "SELECT") && !validateTarget.val()) {
				passport = false;
				if(validateTarget[0].name == "age_area") {
					$.validator.showError(validateTarget, "请选择年级");
				} else {
					$.validator.showError(validateTarget);
				}
				return false;
			} else if (radio) {

			} else if (checkbox) {

			} else if (normalInput && !validateTarget.data("validator")) {
				passport = false;
				return false;
			}
		}

		return passport;
	}


});

//验证码更换
function reFreshImage(valImageId) {
    var objImage = document.images[valImageId];
    if (objImage == undefined) {
        return;
    }

    var now = new Date();

    objImage.src = objImage.src.split('?')[0] + '?x=' + now.toUTCString();
}
