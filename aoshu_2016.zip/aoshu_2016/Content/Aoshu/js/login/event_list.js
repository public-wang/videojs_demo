
/*!VIPABC | Author by Mike Li*/
/*!v1.0 | 2015-3-15*/
/*!License: vipabc.com*/


/*---------------------------------------- 	企业大事件 --------------------------------------------------*/
function big_event() {

	var IsMove = false;                                               //是否移动的标志位
	var num = 10;                                                     // 默认显示年份的数量           
	var $title = $(".eh-year-move ul li");                            //Title选取
	var t_length = $title.length;                                     //目前已有年份的数量
	var t_width = $title.width() + 1;                                 //单个title的宽度
	
	var $content = $(".eh-content div.eh-content-item");              //年份对应的事件
	var $move_ul = $(".eh-year-move ul");                             //整个可移动的Title
	var $y_line = $(".on-year-line");                                 //年份刻度
	
	var winWidth = document.documentElement.clientWidth;              //浏览器的宽度
	if (navigator.userAgent.match(/mobile/i) && WinG.width <= 600 ) {
		num = 4;
	}
	else{
		num = 8;
	}
	var i = t_length - num;                                           //被隐藏年份的个数
	//第一个title的li距离最左侧的距离
	var d = ( $(".eh-year-wrap").width() - num * t_width ) / 2.0 ;   
	
	//为最新的事件添加“new”图标
	$content.eq(t_length - 1).find("ul li").eq(0).removeClass("new-icon").find("span").remove();
	$content.eq( t_length -1 ).find("ul li").eq(0).addClass("new-icon").prepend("<span></span>");
	
	
	if( t_length >= num ){
		
		//默认显示最新的年份列表
		$title.eq( t_length -1 ).addClass("on-year").siblings().removeClass("on-year");
		$content.eq( t_length -1 ).addClass("eh-content-item-on").siblings().removeClass("eh-content-item-on");
		$move_ul.animate({
			"left": - t_width * ( t_length - num ) 
		});	
		$y_line.animate({
			"width": d + t_width * ( num - 0.5 ) 
		},0);
	}
	
	var n_index = $("li.on-year").index();                           //当前显示年份的索引值
	
	
	//鼠标划过切换内容
	if (navigator.userAgent.match(/mobile/i)) {
		$title.click(function() {
			
			var index = $(this).index();
			n_index = index;
			tabMove(n_index);  //引用主函数
			
		});
	}else{
		
		$title.hover(function() {
			
			var index = $(this).index();
			n_index = index;
			tabMove(n_index);  //引用主函数
			
		});
		
	}
	
	
	//左箭头切换
	$(".eh-arrowL").click(function() {
        
		if( n_index > 0){
			
			n_index -= 1;
			if( ( ( n_index > ( num - 1 ) ) && IsMove ) || n_index < i ){
				i -= 1;
			}
			tabMove(n_index); //引用主函数
		}
		
		
    });
	
	//右箭头切换
	$(".eh-arrowR").click(function() {
        
		if( n_index < t_length - 1){
			
			n_index += 1;
			if( ( n_index > ( num - 1 + i ) ) && IsMove ){
				i += 1;
			}
			tabMove(n_index);  //引用主函数
		}
		
    });
	
	//主函数 
	function tabMove(index){

		$title.eq(index).addClass("on-year").siblings().removeClass("on-year");
		$content.eq(index).addClass("eh-content-item-on").siblings().removeClass("eh-content-item-on");

		
		if( index >= ( num - 1 + i ) ){
			
			if( IsMove ){
				
				$move_ul.animate({
				
					"left": - t_width * ( index - num + 1  ) 
				});	
			}
			
			
			$y_line.animate({
				"width":  d + t_width * ( num - 0.5 )
			},0);	
			
			
			if( i >= t_length - num ){
				IsMove = false;
			}
			
		}
		else{

			if(i >= 0 ){
				
				if( index <= i ){
					
					IsMove = true;
					$move_ul.animate({
						"left": - t_width * ( index ) 
					});	
					
					$y_line.animate({
						"width":  d +  t_width * 0.5
					},0);
				}
				else{
					
					index = index - i;
					$y_line.animate({
						"width": d + t_width * ( index + 0.5 )
					},0);
				}
			}
			else{
				
				$y_line.animate({
					"width":  d + t_width * ( index + 0.5 )
				},0);
			}	
		}	
	}
	
};


/*------------------------- 新闻动态 ---------------------------*/
function newsFlash(){
	
	var $title_li = $(".newsflash-title ul li");
	var $content = $(".newsflash-content div");
	
	
	//$title_li.find("img").attr("src",$(this).parents(".newsflash-wrap").find(".newsflash-content div").eq($(this).index()).find("img").attr("src"));
	

	
	if (navigator.userAgent.match(/mobile/i)) {
		$title_li.click(function(){
			
			var _index = $(this).index();
			$(this).addClass("item-on").siblings().removeClass("item-on");
			$content.eq(_index).addClass("newsflash-content-item-on").siblings().removeClass("newsflash-content-item-on");
			
		});	
	}
	else{
		$title_li.hover(function(){
			
			var _index = $(this).index();
			$(this).addClass("item-on").siblings().removeClass("item-on");
			$content.eq(_index).addClass("newsflash-content-item-on").siblings().removeClass("newsflash-content-item-on");
			
		});		
	}
	
	
}




$(document).ready(function(e) {
    
	big_event();                //企业大事件
	newsFlash()                //新闻动态
	

});

//绑定事件监听
onWindowResize.add(big_event);




