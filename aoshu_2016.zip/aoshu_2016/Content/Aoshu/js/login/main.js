
/*!VIPABC | Author by Mike Li*/
/*!v1.0 | 2015-2-27*/
/*!License: vipabc.com*/

$(document).ready(function () {



    /*------------- 鼠标焦点移进，文字消失 ---------------*/
    $(".focus-on").focus(function () {
        var check1 = $(this).val();
        if (check1 == this.defaultValue) {
            $(this).val("");
            $(this).css("color", "#000");
        }
    }).blur(function () {
        if ($(this).val() == "") {
            $(this).val(this.defaultValue);
            $(this).css("color", "#bababa");
        }

    });


    /*----------------- 关闭兼容性提示 ----------------*/
    $(".cp-tips-close").click(function (e) {
        $(".cp-tips").slideUp(400);
    });

    /*----------------- 置顶功能 -----------------*/
    $("#goTop").click(function () {
        $("body,html").animate({
            scrollTop: 0
        },
		500); //点击回到顶部按钮，缓懂回到顶部,数字越小越快
        return false;
    });


    /*手机显示菜单*/
    $(".mobile-nav").click(function (e) {
        $(".nav-wrapper").slideToggle(200);
    });



    /*视频播放*/

    $(".show-video").click(function () {

        var _video_id = $(this).attr("data-name");
//        var _src = wrapUrl("/video/source/" + _video_id + ".mp4");
        var _src = wrapUrl(_video_id);

        var $video_wrap = $("<div class='video-special-wrap'><video id='example_video' class='video-js vjs-default-skin' controls preload='none' width='100%' height='100%' data-setup='{}'><source src='" + _src + "' type='video/mp4' /></video><span id='video-special-wrap-close'></span></div>");

        var _width = 600;
        var _height = 400;
        var _left = "50%";
        if (!(!navigator.userAgent.match(/mobile/i) || navigator.userAgent.match(/iPad/i))) {
            var _width = "80%";
            var _height = 200;
            var _left = "5%";
        }
        else {

        }

        $(".wrapper").append($video_wrap);
        $(".float-lay-bg").fadeIn();
        $(".video-special-wrap").css({
            position: "fixed",
            width: _width,
            height: _height,
            left: _left,
            top: "50%",
            "z-index": 10000,
            "margin-left": -(_width / 2),
            "margin-top": -(_height / 2)
        });


        videojs("example_video", { "autoplay": true });

        $("#video-special-wrap-close").css({

            position: "absolute",
            width: "30px",
            height: "30px",
            right: "-30px",
            top: "-30px",
            "background": "#fff url(" + wrapUrl("/Images/couese_close.png") + ") no-repeat center center",
            cursor: "pointer"

        }).on("click", function (e) {
            _video_id = "";
            _src = "";
            $video_wrap.detach();
            $(".float-lay-bg").hide();

        });

        return false;

    });





    /*----------------- 软件测试专区 --------------------*/

    $(".softwareTest-title ul li").click(function (e) {

        var _index = $(this).index();
        $(this).addClass("item-on").siblings().removeClass("item-on");
        $(".softwareTest-content div.item-content").eq(_index).addClass("item-content-on").siblings().removeClass("item-content-on")

    });


    /*----------------- Top_fix --------------------*/
    if (!navigator.userAgent.match(/mobile/i) || navigator.userAgent.match(/iPad/i)) {

        if (navigator.userAgent.match(/iPad/i)) {

            $("#fix-weixin").focus(function () {
                $(".fix-weixin-warp span").show();
            }).blur(function (e) {
                $(".fix-weixin-warp span").hide();
            });

            $("#fix-app").focus(function () {
                $(".fix-app-warp span").show();
            }).blur(function (e) {
                $(".fix-app-warp span").hide();
            });
        }
        else {
            $("#fix-weibo").hover(function (e) {
                $(this).text("+关注");
            }, function () {
                $(this).text("微博");

            });
            $("#fix-weixin").hover(function () {
                $(".fix-weixin-warp span").show();
            }, function () {
                $(".fix-weixin-warp span").hide();
            });

            $("#fix-app").hover(function () {
                $(".fix-app-warp span").show();
            }, function () {
                $(".fix-app-warp span").hide();
            });
        }


    }


    /*弹出层-体验*/
    if (true) {
        // pc or ipad

        $(".write_contactUs").click(function (e) {

            showWriteToContactUs();

        });


    } else {

        // mobile
        $(".write_contactUs").attr("href", "#yao-form");


    }


});

function showWriteToContactUs() {
    
    if (true) {
        // pc or ipad
        $(".float-lay-bg").fadeIn();
        var container = $(".invisible .write-to-us-container")
                .clone(true)
                .appendTo(".wrapper");

        $(".LayoutForm-wrap-close", container).css({

            position: "absolute",
            width: "16px",
            height: "16px",
            right: "0",
            top: "0",
            margin: "15px 15px 0 0",
            "z-index": 9001,
            "background": "#fff url(//source.vipabc.com/Ext/images/website/abc/homePage/v3/close_icon.png) no-repeat",
            cursor: "pointer"

        }).on("click", function (e) {

            $(this).closest(".write-to-us-container").remove();
            $(".float-lay-bg").hide();

        });
    }
    else {

        // mobile
        
        $('body,html').animate({
                scrollTop: $("#yao-form").offset().top
            },
            100);

        }
}
function TxtNumber(_class, len) {
    $(_class).each(function (index, element) {
        var str = $(this).text();
        var newStr = "";
        var char_length = 0;
        var arr = [];
        for (var i = 0; i < str.length; i++) {
            var son_str = str.charAt(i);
            encodeURI(son_str).length > 2 ? char_length += 1 : char_length += 0.5;
            if (son_str == " ") {
                arr.push(i);
            }
            if (char_length >= len) {
                var sub_len = char_length == len ? i + 1 : i;
                //最后为空格
                if (son_str == " ") {
                    sub_len = i;
                }
                newStr = str.substr(0, sub_len);
                //英文单词
                if (/^[\x00-\xff]/.test(son_str)) {
                    var son_str1 = str.charAt(i + 1);
                    if (/^[\x00-\xff]/.test(son_str1) && arr.length > 0) {
                        newStr = str.substr(0, arr[arr.length - 1]);
                    }
                }
                $(this).text(newStr + " ...");
                break;
            }
        }

    });
}

