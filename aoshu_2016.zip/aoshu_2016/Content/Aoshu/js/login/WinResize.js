/*!VIPABC | Author by Mike Li*/
/*!v1.0 | 2015-2-27*/
/*!License: vipabc.com*/



//全局变量
var WinG = {
    width : 0,
    height: 0
}

//函数findDimensions：获取屏幕尺寸（宽高）
function findDimensions() 
{
    //获取窗口宽度
    if (window.innerWidth)
        WinG.width = window.innerWidth;
    else if ((document.body) && (document.body.clientWidth))
        WinG.width = document.body.clientWidth;
    //获取窗口高度
    if (window.innerHeight)
        WinG.height = window.innerHeight;
    else if ((document.body) && (document.body.clientHeight))
        WinG.height = document.body.clientHeight;
    //通过深入Document内部对body进行检测，获取窗口大小
    if (document.documentElement && document.documentElement.clientHeight && document.documentElement.clientWidth) {
        WinG.height = document.documentElement.clientHeight;
        WinG.width = document.documentElement.clientWidth;
    }
}

//初始化函数
findDimensions();


//对象onWindowResize：
/*
    用于解决 lte ie8 & chrome 及其他可能会出现的 原生 window.resize 事件多次执行的 BUG.
    //add: 添加事件句柄
    //remove: 删除事件句柄

*/
var onWindowResize = function(){
    //事件队列
    var queue = [],
 
    indexOf = Array.prototype.indexOf || function(){
        var i = 0, length = this.length;
        for( ; i < length; i++ ){
            if(this[i] === arguments[0]){
                return i;
            }
        }
 
        return -1;
    };
 
    var isResizing = {}, //标记可视区域尺寸状态， 用于消除 lte ie8 / chrome 中 window.onresize 事件多次执行的 bug
    lazy = true, //懒执行标记
 
    listener = function(e){ //事件监听器
        var h = window.innerHeight || (document.documentElement && document.documentElement.clientHeight) || document.body.clientHeight,
            w = window.innerWidth || (document.documentElement && document.documentElement.clientWidth) || document.body.clientWidth;
 
        if( h === isResizing.h && w === isResizing.w){
            return;
 
        }else{
            e = e || window.event;
         
            var i = 0, len = queue.length;
            for( ; i < len; i++){
                queue[i].call(this, e);
            }
 
            isResizing.h = h,
            isResizing.w = w;
        }
    }
 
    return {
        add: function(fn){
            if(typeof fn === 'function'){
                if(lazy){ //懒执行
                    if(window.addEventListener){
                        window.addEventListener('resize', listener, false);
                    }else{
                        window.attachEvent('onresize', listener);
                    }
 
                    lazy = false;
                }
 
                queue.push(fn);
            }else{  }
 
            return this;
        },
        remove: function(fn){
            if(typeof fn === 'undefined'){
                queue = [];
            }else if(typeof fn === 'function'){
                var i = indexOf.call(queue, fn);
 
                if(i > -1){
                    queue.splice(i, 1);
                }
            }
 
            return this;
        }
    };
}.call(this);


//绑定window 的 resize 事件

onWindowResize.add(findDimensions);
