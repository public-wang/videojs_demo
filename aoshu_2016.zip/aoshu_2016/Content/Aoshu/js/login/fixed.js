
/*!VIPABC | Author by Mike Li*/
/*!v1.0 | 2015-2-27*/
/*!License: vipabc.com*/

//全局变量
var winTop = $(window).scrollTop();      //鼠标滚动的高度
var Is_show = false;
var Is_show2 = false;

/*----------------- 主导航 跟随鼠标 滚动 -----------------*/
	 
function nav_fixed(e){
	
	//e = e || window.event;  	
	//顶部菜单随滚动一起浮动
	var winTop = $(window).scrollTop();
	var $Fixed2 = $(".header-fixed");

	if(!$Fixed2.length || !$(".header-float").length) {
		return false;
	}

	var $offset2 = $(".header-float").offset();
	
	
	if (!navigator.userAgent.match(/mobile/i)) {
		//PC下
		if( winTop > 30 ){
			if( Is_show2 === false ){
				
				Is_show2 = true;
				$Fixed2.css({
				    "position": "fixed",
				    "_position": "absolute",
				    "top": "0",
				    "left": $offset2.left + "px",
				    "z-index": 2000,
				    "box-shadow": "0 1px 3px rgba(0,0,0,0.4)"

				});
			}
			else{
				$Fixed2.css({
					"top":"0px"
				});	
			}
			
			
		}else{
			$Fixed2.removeAttr("style");
			Is_show2 = false;
			
		}	
	
	}
	
		     
};
/*----------------- 主导航 跟随鼠标 滚动 end -----------------*/


/*----------------------- 右侧浮动表单框 -------------------*/
function sidebar_fixed() {

	if(!$(".sidebar").length || !$(".container .v-jr-center").length || !$("#js-footer").length) {
		return false;
	}

    var winTop = $(window).scrollTop();
    var screenHeight = window.innerHeight;
    var bodyHeight = window.document.body.offsetHeight;
	var $Fixed = $(".sidebar");
    var $offset = $(".container .v-jr-center").offset(); //不能用自身的div，不然滚动起来会很卡
    var _left = $offset.left + 1000;
    var slideHeight = $Fixed.height();
    var FooterHeight = $("#js-footer").height();
	var _stop = $("#js-footer").offset().top;
	
	if (!navigator.userAgent.match(/mobile/i)) {
		//PC下				
		if( winTop > $offset.top - 60 ){
		    var currentTop = _stop - winTop;
		    if (currentTop < FooterHeight + slideHeight) {

		        $Fixed.css({
		            "_position": "fixed",
		            "position": "absolute",
		            "top": _stop - slideHeight - FooterHeight + "px",
		            "left": _left,
		            "z-index": 888
		        });

		    } else {
		        $Fixed.css({
		            "position": "fixed",
		            "_position": "absolute",
		            "top": "116px",
		            "left": _left,
		            "z-index": 1039
		        });
		    }

        }else{
			$Fixed.removeAttr("style");
		}
	
	}

}
/*----------------------- 右侧浮动表单框 end -------------------*/


function fixedAll(){
	nav_fixed();
	sidebar_fixed();
}

$(document).ready(function(e) {
   fixedAll(); 
});

$(window).scroll(function(e) {
    fixedAll(); 
});

/*//给页面绑定滑轮滚动事件  
if (document.addEventListener) {//firefox  
	document.addEventListener('DOMMouseScroll', fixedAll, false);  
}  
//滚动滑轮触发scrollFunc方法  //ie 谷歌  
window.onmousewheel = document.onmousewheel = fixedAll; */

