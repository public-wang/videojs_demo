/**
 * Created by harry on 16/5/10.
 */

//+ function($, window, undefined) {
    $(function() {

        /**
         * top 图片显示隐藏
         */
        $(".js-top-show-handle").hover(function() {
            $(this).find(".v-jr-img-holder").stop().show();
        }, function() {
            $(this).find(".v-jr-img-holder").stop().hide();
        });

        $(window).on("scroll", function() {
            var topElement = $("#js-slide-box");
            var top = topElement.offset().top - 0;
            var scrollTop = $(window).scrollTop();

            if (scrollTop > 40 + top) {
                $("#js-nav").addClass("v-jr-nav-scroll");
                topElement.addClass("v-jr-slide-scroll");
            } else {
                $("#js-nav").removeClass("v-jr-nav-scroll");
                topElement.removeClass("v-jr-slide-scroll");
            }
        });

        $(window).trigger("scroll");

        //! 登录后,退出按钮显示/隐藏
        $("#js-nav-login-msg").hover(function() {
            $(this).addClass("active");
        }, function() {
            $(this).removeClass("active");
        });

    });


    // mobile
    $(function() {

        /**
         * mobile 中bar功能
         */
        $("#js-slide-bar").on("click", function() {
            //! 处理bar打开后fixed跑偏的问题
            $("body").addClass("_slide-active");
            return false;
        });

        $("#js-slide-box").on("click", function() {
            $("body").removeClass("_slide-active");
        });

        //$("#js-slide-box::after").on("touchend", function() {
        //    $("body").removeClass("_slide-active");
        //    return false;
        //});

    });

//}(jQuery, window, undefined);