/*!VIPABC | Author by Michael Han*/
/*!v1.0 | 2015-3-26*/
/*!License: vipabc.com*/

var clientValidation = function (vals) {
    this.rules = {
        mail1:
            {
                reg: "^([a-zA-Z-z0-9_\.-]+)@([\\da-zA-Z\\.-]+)\\.([a-zA-Z\\.]{2,6})$",
                msg: "请输入正确的电子邮箱. e.g. VIPABC@example.com"
            }
    };

    // events
    this.onValidated = null;

    var me = this;

    this.validate = function () {
        var isValid = true;
        $(vals).each(function (i, context) {

            var o = $(context.input);

            var result = {
                isValid: true,
                msg: [],
                source: o
            };

            var val = $.trim(o.val());

            var check = true;
            // check required
            if (o.hasClass("v-required")) {
                check = !o.hasClass("with-hint") && true;

                check = val.length > 0 && !o.hasClass("with-hint");

                if (!check) {
                    result.msg.push(o.data("v-required-msg"));
                }
                result.isValid = result.isValid && check;
            }

            // check number range
            if (o.hasClass("v-num-range")) {
                check = !o.hasClass("with-hint") && true;
                var min = o.data("min");
                if ($.isNumeric(min)) {
                    min = Number(min);
                }

                var max = o.data("max");
                if ($.isNumeric(max)) {
                    max = Number(max);
                }

                if (min != "" && min != undefined && min != null) {
                    check = check && Number(val) >= min;
                }

                if (max != "" && max != undefined && max != null) {
                    check = check && Number(val) <= max;
                }

                if (!check) {
                    result.msg.push(o.data("v-num-range-msg"));
                }

                result.isValid = result.isValid && check;
            }

            // check string length
            if (o.hasClass("v-length")) {

                check = !o.hasClass("with-hint") && true;

                var min = o.data("min");
                if ($.isNumeric(min)) {
                    min = Number(min);
                }

                var max = o.data("max");
                if ($.isNumeric(max)) {
                    max = Number(max);
                }


                if (min != "" && min != undefined && min != null) {
                    check = check && val.length >= min;
                }

                if (max != "" && max != undefined && max != null) {
                    check = check && val.length <= max;
                }


                if (!check) {
                    result.msg.push(o.data("v-length-msg"));
                }

                result.isValid = result.isValid && check;
            }

            // reg check
            if (o.hasClass("v-reg")) {
                check = !o.hasClass("with-hint") && true;

                $(o.data("reg-rules").split(",")).each(function (j, rule) {
                    for (var key in me.rules) {
                        if (key == rule) {
                            var reg = new RegExp(me.rules[key].reg);
                            var msg = me.rules[key].msg;
                        
                            check = true;

                            check = check && reg.test(val);
                            if (!check) {
                                result.msg.push(msg);
                            }
                            result.isValid = result.isValid && check;
                        }
                    }
                });
            }

            if (me.onValidated) {
                me.onValidated(result);
            }

            isValid = isValid && result.isValid;
        });


        return isValid;
    };
};