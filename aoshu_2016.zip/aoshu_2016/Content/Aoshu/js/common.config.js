//处理接收名单的api
var index_exe_api_url="http://192.168.237.28:9001/program/linkage_page/include/index_exe_api.asp";
var index_sms_api_url="http://192.168.237.28:9001/program/linkage_page/include/index_sms_api.asp";
if (window.location.host.indexOf("stage") > -1) {
    index_exe_api_url = "http://stage.vipabc.com/program/linkage_page/include/index_exe_api.asp";
    index_sms_api_url = "http://stage.vipabc.com/program/linkage_page/include/index_sms_api.asp";
}
