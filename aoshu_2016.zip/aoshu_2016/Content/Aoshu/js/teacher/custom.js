/*!VIPABC | Author by Gongyou Wang*/
/*!v2.0 | 2016-11-22*/
/*!License: vipabc.com*/

$(document).ready(function() {

  	/*form表单年龄改成年级*/
	$.vForm.validate = function (rules) {
		var passport = true;

		for (var key in rules) {
			var isExist = !!this.find("[name='" + key + "']").length,
				validateTarget = this.find("[name='" + key + "']"),
				radio = isExist && $.nodeName(validateTarget[0], "INPUT") && validateTarget[0].type == "radio",
				checkbox = isExist && $.nodeName(validateTarget[0], "INPUT") && validateTarget[0].type == "checkbox",
				normalInput = isExist && $.nodeName(validateTarget[0], "INPUT") && !radio && !checkbox;

			normalInput && validateTarget.trigger("blur");
			if (isExist && $.nodeName(validateTarget[0], "SELECT") && !validateTarget.val()) {
				passport = false;
				if(validateTarget[0].name == "age_area") {
					$.validator.showError(validateTarget, "请选择年级");
				} else {
					$.validator.showError(validateTarget);
				}
				return false;
			} else if (radio) {

			} else if (checkbox) {

			} else if (normalInput && !validateTarget.data("validator")) {
				passport = false;
				return false;
			}
		}

		return passport;
	}

	/*form表单年龄改成年级*/
	$.vForm.afterSubmit = function (data, postData) {
		var JSUUID = data.JSUUID ? data.JSUUID : "";

		window.location.href = "http://page.vipabc.com/landingpage/include/thankyou.html?fromwhere=" + $.vForm.getQueryString("fromwhere") + "&jsid=" + JSUUID;
	}

	$('.slick0').slick({
		dots: true
	});

	/*tabs样式滑动*/
	function setTab(n){
	 var $tli = $(".tabs-menu li");
	 var $mli = $(".tabs-main ul");
	 var $slick = $(".tabs-main .ppt");
	 for(i=0;i<$tli.length;i++){
	 	$($tli[i]).removeClass("hover").addClass(i==n?"hover":"");
	 	$($mli.get(i)).css("display", i==n?"block":"none");
	  	$($slick.get(i)).css("display", i==n?"block":"none");
	 }
	}

	$(".tabs-menu li").each(function(i){
		
		$(this).on("click", function(event){
			event.stopPropagation();
			
			setTab(i);
			if (!$('.slick'+i).hasClass("slick-initialized")){
				$('.slick'+i).slick({
					dots: true
				});
			}
		});

	});


});
